
stem_ip plug-in for imageJ, 12-dec-2015 ejk

This imageJ plugin performs image restoration (deconvolution) on ADF-STEM images in the incoherent
image model using a Wiener filter or the Richardson-Lucy method (with a Gaussian prefilter as
in 5).  The adaptive median filter can also be used to reduce simple impulsive (salt-and-pepper)
noise. Copy the file stem_ip.jar into the imageJ Plugins directory. When imageJ is restarted,
the stem_ip command should appear under the Plugins menu. Open stem_ip and an image to be processed.
Fill in the image parameters in the stem_ip window (very important) and click on run. A 512x512
image may take a few seconds on a laptop (RL).  The strength of the Wiener filter is controlled
with the SNR parameter and the strength of Richarson-Lucy is controlled by the number of iterations.
Adjust these values till the image looks its best.  Requesting too much produces poor results
(usually enhances the noise). There is a trade off between signal-to-noise ratio (SNR) and the
amount of image improvement that can be obtained. Typical ADF-STEM images usually receive a small
improvement in apparent contrast. 

references:

---Wiener Filter, and Adaptive Median Filter ----
1. R. C. Gonzalez and R. E. Woods, "Digital Image Processing",
	Prentice Hall, 2008 (3rd edit.)

---the RL method ---
2. W. H. Richardson, J. Opt. Soc. Amer. 62 (1972) p.55-59.
3. L. B. Lucy, The Astronomical Journal, 79 (1974) p.745-754.
4. L. A. Shepp and Y. Vardi, IEEE Trans. on Medical Imaging,
    1, (1982), p.113-122.
5. 	G. M. van Kempen and L. J. van Vliet and P. J. Verveer and
	H. T. M. van der Voort, Journal of Microscopy, 185, (1997), p.354-365.
 

------------------------------------------------------------------------
Copyright 2015 Earl J. Kirkland

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

---------------------- NO WARRANTY ------------------
THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL THE AUTHOR BE LIABLE
FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
ANY OTHER PROGRAM). 

------------------------------------------------------------------------
