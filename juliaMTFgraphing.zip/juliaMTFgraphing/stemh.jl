#
#  stemh.jl
#
#------------------------------------------------------------------------
#Copyright 2020 Earl J. Kirkland
#
# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  functions to calculate ADF-STEM probe (psf) and mtf
#
#  lensr, lensi = real and imag part of aber. function to integrate
#  prbsize = calculate the size of the probe
#  stemhk  = calculate STEM transfer function (calls stemhrCC)
#  stemhr  = calculate STEM probe profile vs. r
#  stemhrCc =  calculate STEM probe profile
#                  vs. r including chromatic aber. (calls stemhr)
#  wavelen = calculate electron wavelength for given keV
#
#   started 15-sep-2020 ejk
#   all working 14-nov-2020 ejk
#   last modified 16-nov-2020 ejk
#

using SpecialFunctions  # for besselj0(), besselj1()
using QuadGK            # for quadgk() integration

#  ADF STEM objective parameters
mutable struct STEMpar
    kev::Float64    # beam voltage in keV
    Cs3::Float64    # in mm.
    Cs5::Float64    # in mm.
    df::Float64     # in Ang.
    amax::Float64   # obj. apert. in mrad
    ddf::Float64    # defocus spread in Ang.
end


#-------- lens(k) ----------------
#
#  dummy function to integrate (used by stemhr)
#  to calculate complex aberr. function
#    input k (in 1/Angs.), wav = electron wavelength
#
#  chi = pi*wav*k^2*[ 0.5*Cs3*wav^2*k^2
#                  + (1/3)*Cs5*wav^4*k^4 - df ]
#  return exp( -i*chi )
#
# globals:
#   w2 = pi*defocus*wav
#   w4 = 0.5*pi*Cs3*wav^3
#   w6 = (1.0/3.0)*pi*Cs5*wav^5
#   intr = 2*pi*r
#
#  started from stemh.py 16-sep-2020 E. Kirkland
#
function lensr( k )::Float64    #  real part
    global w2, w4, w6, intr  # constants
    k2 = k*k
    w = ( (w6*k2 + w4) *k2 - w2 )*k2
    return cos(w) * besselj0( intr*k )*k
end     #  end lensr()

function lensi( k )::Float64    #  imag part
    global w2, w4, w6, intr  # constants
    k2 = k*k
    w = ( (w6*k2 + w4) *k2 - w2 )*k2
    return -sin(w) * besselj0( intr*k )*k
end     #  end lensi()

#
#-------- prbsize() ----------------
#
# function prbsize() to calculate
#       FWHM-II size from results stemhr()
#       II = integrated intensity meaning diameter of half current
#    input array r has the radial positions (in Angs.)
#    input array psf has probe intensity from stemhr()
#    output is the size
#
function prbsize( r::Vector{Float64}, psf::Vector{Float64}  )
    nr = length(r)
    psf2 = copy(psf)  # make new array to work with
    psf2[1] = psf2[1] * r[1];
    for ir= 2:nr  # integrated intensity
        psf2[ir] = psf2[ir-1] + psf2[ir]*r[ir]
    end

    j = 1   #  keep in outer loop
    amax = 0.5 * psf2[nr]  # should be half max. value
    for i= 1:nr
        ir = nr-i+1  # go from nr to 1
        j = ir
        if( psf2[ir] < amax )
             break
        end
    end

    if( j <= 1 )
        return 2.0*r[2]  # avoid divide by zero below
    end

    #  interpolate to get a little more accurate
    d = abs( (r[j+1]-r[j])*(amax-psf2[j])/(psf2[j+1]-psf2[j]) )
    return 2.0*( r[j] + d)

end   #  end prbsize()

#
#-------- stemhk() ----------------
#
#   function to calculate STEM mtf vs. k
#    input array k has the spatial freq. (in inv. Angs.)
#    input variable params has the optical parameters
#          [Cs, df, kev, amax] as elements
#    output array contains the transfer function
#
#  params = [kev, Cs3, Cs5, df, amax, ddf ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#  ddf  = FWHM of defocus spread (in Angstroms)
#
function stemhk( k::Vector{Float64}, params::STEMpar,
    mtf::Vector{Float64}  )
    kev = params.kev
    Cs3 = params.Cs3*1.0e7
    #  first calculate the psf using stemhr()
    nr = 500  # number of points in integral over r
    wav = wavelen(kev)  # electron wavelength
    Cs = abs(Cs3)
    if Cs < 0.1e7
         Cs = 0.1e7
    end
    rmin = 0.0
    rmax = 2.0*sqrt( sqrt( Cs*wav*wav*wav) )
    r= range( rmin, stop=rmax, length=nr)
    r = collect( r )  # convert to a vector
    psf = Vector{Float64}(undef,nr)
    stemhrCc( r, params, psf )
    # next invert psf to get mtf
    nk = length( k )
    h = Vector{Float64}(undef,nr)
    for ik= 1:nk
        for ir= 1:nr
            h[ir] = psf[ir] * besselj0(2*pi*r[ir]*k[ik] ) *r[ir]
        end
        mtf[ik] = sum(h)
    end
    a = mtf[1]
    for ik= 1:nk    # normalize to mtf(1)=1
        mtf[ik] /= a
    end
    #mtf /= a    # normalize to mtf(1)=1 - doesn't work(?)

end   #  end stemhk()

#
#-------- stemhr() ----------------
#
# function stemhr to calculate
#            STEM probe profile vs. r
#    input array r has the radial positions (in Angs.)
#    input variable params has the optical parameters
#    output array contains the psf
#
#  params = [kev, Cs3, Cs5, df, amax, ddf ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#  ddf = defocus spread = not used here
#
function stemhr( r::Vector{Float64}, params::STEMpar,
    psf::Vector{Float64} )
    global w2, w4, w6, intr  # constants for lensr,i()
    kev = params.kev
    Cs3 = params.Cs3*1.0e7
    Cs5 = params.Cs5*1.0e7
    df = params.df
    amax = params.amax*0.001
    wav = wavelen(kev)  # electron wavelength
    kmax = amax/wav
    w2 = wav*pi*df
    w4 = 0.5*pi*Cs3*wav*wav*wav
    w6 = pi*Cs5*wav*wav*wav*wav*wav /3.0
    nr = length( r )
    for ir= 1:nr
        intr = 2*pi*r[ir]
        # use adaptive quadrature because integrand
        #     not well behaved
        hrr= quadgk( lensr, 0, kmax, rtol=1.0e-5 )
        hri= quadgk( lensi, 0, kmax, rtol=1.0e-5 )
        psf[ir] = hrr[1]*hrr[1] + hri[1]*hri[1]
    end

    a = maximum(psf)
    # norm. probe intensity to a max. of 1
    for ir= 1:nr
        psf[ir] /= a
    end

end     #  end stemhr()

#
#-------- stemhrCc() ----------------
#
# function stemhrCc to calculate
#       STEM probe profile vs. r including chromatic aber.
#    input array r has the radial positions (in Angs.)
#    input variable params has the optical parameters
#    output array contains the psf
#
#  params = [kev, Cs3, Cs5, df, amax, ddf ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#  ddf  = FWHM of defocus spread (in Angstroms)
#
# Gauss-Hermite Quadrature
#       with exp(-x*x) weighting of integrand
#       from Abramowitz and Stegun, and Numerical Recipes
#
function stemhrCc( r::Vector{Float64}, params::STEMpar,
    psf::Vector{Float64}  )
    NGH = 9  # number of Gauss-Hermete coeff. to use
    # absiccas and weights for Gauss-Hermite Quadrature
    xGH= [ 3.190993201781528, 2.266580584531843, 1.468553289216668,
        0.723551018752838, 0.000000000000000, -0.723551018752838,
        -1.468553289216668,-2.266580584531843,-3.190993201781528]
    wGH= [3.960697726326e-005, 4.943624275537e-003 ,8.847452739438e-002,
        4.326515590026e-001, 7.202352156061e-001, 4.326515590026e-001,
        8.847452739438e-002, 4.943624275537e-003, 3.960697726326e-005]

    df0 = params.df   #  defocus mean
    ddf = params.ddf   # defocus spread FWHM in Angst.

    nr = length( r )

    #  no defocus integration with small df spread
    if( ddf < 1.0 )
        stemhr( r, params, psf )
        a = maximum(psf)
        # norm. probe intensity to a max. of 1
        for ir= 1:nr
            psf[ir] /= a
        end
        return
    end

    #  integrate over defocus spread
    ndf = NGH
    ddf2 = sqrt(log(2.0)/(ddf*ddf/4.0))  # convert from FWHM
    psf1 = Vector{Float64}(undef,nr)
    for ir= 1:nr
        psf[ir] = 0.0
    end
    for idf= 1:ndf
        df = df0 + xGH[idf]/ddf2
        #weight =  wGH[idf]
        params.df = df
        stemhr( r, params, psf1 )
        a = sum( psf1 .* r )  # normalize to total current
        weight = wGH[idf]/a
        #psf = psf + weight*psf1  #  doesn't work - make a new local psf(?)
        for ir= 1:nr
            psf[ir] += weight*psf1[ir]  # this works!
        end
    end

    params.df = df0    #  restore original value
    a = maximum(psf)
    # norm. probe intensity to a max. of 1
    for ir= 1:nr
        psf[ir] /= a
    end
end     #  end stemhrCC()

#------- wavelen()-------
#
# return electron wavelength in Ang. for keV
#
function wavelen(kev)
    return( 12.3986/sqrt((2*511.0+kev)*kev) )
end     #  end wavelen()
