#
#   stempsf.jl
#
#------------------------------------------------------------------------
#Copyright 2020 Earl J. Kirkland
#
# This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  calculate ADF-STEM psf or probe
#
#  uses julia packages Plots, SpecialFunctions, QuadGK
#  and subroutines in stemh.jl
#
#  started 15-sep-2020 ejk
#  last modified 20-oct-2020 ejk
#

using Plots             # plotting package
pyplot()

include("stemh.jl") # get subroutines

npts = 300  # number of points in graph

# print a prompt and read back a value
function myinput( prompt::String)::Float64
    println(prompt)
    x = parse(Float64, chomp(readline()) )
    return( x )
end

println( "Plot ADF STEM point spread function..." )

cc= "m"

while ( (cc == "m") || (cc=="M") )
    println("type in optical parameters...")

    kev = myinput("Type energy in keV: ")
    Cs3 = myinput("Type Cs3 in mm.:")
    Cs5 = myinput("Type Cs5 in mm.:")
    df = myinput("Type defocus in Ang:")
    ddf = myinput("Type defocus spread in Ang:")
    amax = myinput("Type objective angle in mr.:")

    p = STEMpar(kev, Cs3, Cs5, df, amax, ddf)

    wav = wavelen(kev)  # electron wavelength
    Cs = abs(Cs3)
    if Cs < 0.1
        Cs = 0.1
    end
    rmin = 0.0
    rmax = sqrt( sqrt( Cs*1.0e7*wav*wav*wav ))

    r= range( rmin, stop=rmax, length=npts)
    r = collect( r )  # convert to a vector
    psf = Vector{Float64}(undef,npts)

    stemhrCc( r, p, psf )
    rfwhm = prbsize( r, psf )
    println( "FWHM-II= ", rfwhm, " Ang." )
    s1 = "E= $kev keV, Cs3= $Cs3 mm, Cs5= $Cs5 mm, \n df= $df A,  ddf= $ddf A"
    display( plot( r, psf, title=s1, legend= false) )
    display(xlabel!( "radius in Angstroms" ))
    display(ylabel!( "PSF" ))
    savefig( "ADFstem_psf.pdf" )   # choose file name and format

    # pause here to keep graph on screen to see and interact
    # remember: global variables (cc) are hidden!
    println("stempsf done, type m for more")
    global cc = readline()

end   # end while( cc... )
