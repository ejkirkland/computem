/*              *** rfpix_mac.cpp ***

Alternate version for Apple Mac only
required link option:   -framework Accelerate

 ------------------------------------------------------------------------
Copyright 2024-2026 Earl J. Kirkland

This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

---------------------- NO WARRANTY ------------------
THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL THE AUTHOR BE LIABLE
FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
ANY OTHER PROGRAM). 

------------------------------------------------------------------------

    The Apple Arm CPU on the Mac does not have a precision timer so FFTW
    cannot find the optimal FFT form and defaults to a slow FFT.
    The Apple Accelerate Framework has a faster FFT just for the Apple CPU
    but is only for powers of 2 (FFTW has all lengths).
    Make a special version of rfpix.cpp for the Apple Mac.
    
    The Apple c2r FFT has a strange pixel ordering which is hard to use and
    hard to understand, so just use the c2c version and fill in one half 
    plan by symmetry.  There is not an obvious easy way to make the Apple
    vDSP_fft2d_zrip() mimic the FFTW subroutine. This FFT is not used much
    in multislice so there should not be much performance penalty.

   C++ class to manage complex/real floating point images (in ANSI-C++)

   collect (isolate) the FFT details here so it can be easily changed in future

   perform real to real and its inverse

   FFTW real to complex FFT's use two separate arrays one real and one complex
    real nx x ny
    complex nx x (ny/2+1)
    forward xform = real to complex and inverse xform = complex to real

  the FFT is NOT performed in place

The source code is formatted for a tab size of 4.

----------------------------------------------------------
The public member functions are:

nx()       : return x size of current image (in pixels)
ny()       : return y size of current image (in pixels)

re(ix,iy)  : return reference to real part of pixel at (ix,iy)
im(ix,iy)  : return reference to imag part of pixel at (ix,iy)

rre(ix,iy) : return reference to pixel at (ix,iy) of the
             real image for complex to real transform

fft()      :  perform FFT
ifft()     : inverse FFT

init()     : perform initialization
copyInit() : copy the initialization

resize()        : resize current in-memory image (current data may be lost)
findRange()     : find range of values in complex image

operator=()

----------------------------------------------------------

   started from cfpix 7-may-2024 E. Kirkland
   working 18-may-2024 ejk
   add alternate mac version 31-aug-2025 to 1-sep-2025 ejk
   change a few comments 26-oct-2025 ejk
   fix x/y order error in fft call 18-nov-2025 elk
   fix FFT directions 31-jan-2026 ejk
   last modified 31-jan2026 ejk
*/

#include "rfpix.hpp"    // class definition + inline functions here

#include <sstream>  // string streams

#include "slicelib.hpp"    // misc. routines for multislice

//------------------ constructor --------------------------------

rfpix::rfpix( int nx, int ny )
{
    nxl = nyl = nycl = nrxyl = 0;

    lengthOK = 0;   // not OK

    if( (nx > 0 ) && ( ny > 0 ) ) resize( nx, ny );

}  // end rfpix::rfpix()

//------------------ destructor ---------------------------------
rfpix::~rfpix()
{
    if ((nxl > 0) && (nyl > 0)) {
        delete [] rdata;
        delete [] idata;
    }

    nxl = nyl = nycl = nrxyl = 0;
    lengthOK = 0;

}  // end rfpix::~rfpix()

//------------------ copyInit ---------------------------------
//  not needed on mac,  dummy return
void rfpix::copyInit( rfpix &xx)
{
    return;

}  // end rfpix::copyInit()


//------------------ forward transfrom ---------------------------------
//  --- mimic a r2c FFT using a full c2c (may be a little slower but should work OK)
//  - zero the imaginary part and do c2c FFT
void rfpix::fft()
{
    int ix, iy, j;

    if( 0 == lengthOK ){
        sbuff= "rfpix fft invoked with length not a power of 2 (required by Apple):\n"
                +toString(nxl)+" x "+ toString(nxl);
        messageRF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }

    cdata.realp = rdata;   // store real,imag data pointers in Apple structure 
    cdata.imagp = idata;
    
    for( ix=0; ix<nxl; ix++) {  //  zero the imag part for a r2c FFT
        j = ix*nyl;
        for( iy=0; iy<nyl; iy++) {
            idata[j++] = 0.0F;  //  imag data[iy + ix*ny]  -- not really needed
        }
    } /* end for(ix..) */
    
    //   perform the complex in-place FFT 
    //    remember direction must be opposite to mine and same as FFTW
    //        because r2C in FFTW is a fixed direction
    //      fix sign in calling program
    vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Forward);
    //vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Inverse);
    
}  // end rfpix::fft()

//------------------ inverse transfrom ---------------------------------
void rfpix::ifft()
{
    int nxyt= nxl*nyl, ix, iy, ix2, iy2, j;
    float scale;

    if( 0 == lengthOK ){
        sbuff= "rfpix ifft invoked with length not a power of 2 (required by Apple):\n"
                +toString(nxl)+" x "+ toString(nxl);
        messageRF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }
    
    //  fill in one half plan with Friedel's law (for real valued data)
    //      F(k) = F^*(-k)
    //  assume iy<(ny/2+1)=nycl already set
    for( ix=0; ix<nxl; ix++) {
        if( ix==0) ix2=0;
        else ix2 = nxl - ix;
        for( iy=nycl;  iy<nyl; iy++) {
            iy2 = nyl - iy;
            rdata[ iy + ix*nyl] =  rdata[iy2 + ix2*nyl];
            idata[ iy + ix*nyl] = -idata[iy2 + ix2*nyl];
        }
    }
 
    cdata.realp = rdata;   // store real,imag data pointers in Apple structure
    cdata.imagp = idata;
   
    //   perform the complex in-place FFT 
    //    remember direction must be opposite to mine and same as FFTW
    //        because r2C in FFTW is a fixed direction
    //      fix sign in calling program
    //vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Forward);
    vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Inverse);
        
    /*  multiplied by the scale factor */
    scale = 1.0F/( (float)(nxl * nyl) );

    #ifdef OLDCODE
    for( j=0; j<nxyt; j++) {
            rdata[j] *= scale;  //  real data[iy + ix*ny]
            idata[j] *= scale;  //  imag data[iy + ix*ny]  -- may not be needed
    }
    #endif

    //  this didn't improve speed sig. amount (maybe 1%?) (31-dec-2025 ejk)
    vDSP_vsmul( rdata,  1, &scale, rdata, 1, nxyt );
    vDSP_vsmul( idata,  1, &scale, idata, 1, nxyt );

    }  // end rfpix::ifft()

//------------------ initializer ---------------------------------
//
// not needed for Apple Accelerate
//  dummy return
void rfpix::init( int mode, int nthreads )
{
    return;

}  // end rfpix::init()



/*------------------------- messageRF() ----------------------*/
/*
    common message output
    redirect all print message to here so this can be redirected
        to a dialog box in a GUI or cmd line 

   stemp[] = character string with message to disply
   level = level of seriousness
            0 = simple status message
        1 = significant warning
        2 = possibly fatal error
*/
void rfpix::messageRF( std::string &smsg,  int level )
{
    messageSL( smsg.c_str(), level );  //  just call slicelib version for now
}

//--------------------- operator=() ----------------------------------
//  element by element copy (only data not plan)
//   real data not implemented yet
rfpix& rfpix::operator=( const rfpix& m  )
{
    int nxyt= nxl*nyl, nxyct= nxl*nycl;

    if( (m.nxl != nxl) || (m.nyl != nyl)  ){
        sbuff= "rfpix operator= invoked with unequal sizes:\n"
                +toString(nxl)+" x "+ toString(nxl) +" and "
                + toString(m.nxl)+" x "+ toString( m.nxl );
        messageRF( sbuff, 2 );
        exit( EXIT_FAILURE );
    } else if( (nxl>0) && (nyl>0) ) {

        for( int i=0; i<nxyt; i++) {
           rdata[i] = m.rdata[i];   //  real part 
           idata[i] = m.idata[i];   //  imag part
        }
    } else {
        sbuff= "bad operator=() in rfpix"; // gcc requires this step
        messageRF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }

    return *this;

}     //  end  rfpix::operator=()

//--------------------- operator=() ----------------------------------
//  initial to a real value
//   
rfpix& rfpix::operator=( const float xf )
{
    int nxyt = nxl * nyl, nxyct = nxl * nycl;

    if( (nxl > 0) && (nyl>0)  ) {
        int i;
        for( i=0; i<nxyt; i++) {  // can't do FFT part yet
           rdata[i] = xf;        //  real part 
           idata[i] = 0.0F;      //  imag part
        }
    } else {
        resize( 1, 1 );    //  just do what we can...
        rdata[0] = xf;
        idata[0] = 0.0F;
    }

    return *this;
}     //  end  rfpix::operator=()


//------------------------- pwr2() ------------------------*/
//
//    return the nearest power of 2 greater than or equal to 
//    the argument
//    - from powerof2() in fft2dc.c
//
int rfpix::pwr2( int n )
{
        int ln;
        int n2;

        ln = 1;
        n2 = 2;
        while( (n2 < n) && (ln<25) ) { n2*=2; ln++; }

        return( n2 );
}


//--------------------- resize() ----------------------------------
//  resize data buffers 
//   nx, ny = new size of real image
//  note: existing data (if any) may be destroyed
//
int rfpix::resize( const int nx, const int ny )
{
    if( (nx != nxl) || (ny != nyl) ){
        if ((nxl != 0) && (nyl != 0)) {
            delete [] rdata;
            delete [] idata;
        }
        nxl = nx;
        nyl = ny;
        nycl = ny/2 + 1;
        rdata =  new float[ nx*ny ];
        idata =  new float[ nx*ny ];
        if( (NULL == rdata) || (NULL == idata) ) {
            sbuff= "Cannot allocate complex array memory in rfpix::resize()";
            messageRF( sbuff, 2 );
            return( -1 );
        }
    
        lnx = (long) ( log( (double) nxl )/log(2.0) + 0.5 );
        lny = (long) ( log( (double) nyl )/log(2.0) + 0.5 );

        int nxTest = pwr2( nx );   // Apple length be a power of 2
        int nyTest = pwr2( ny );
        if( (nxTest == nx) && (nyTest == ny) && (nx <= 1024) && (ny <= 1024) ) 
            lengthOK = 1;
        else lengthOK = 0;
        
        setup = vDSP_create_fftsetup(MAX(lnx, lny), FFT_RADIX2);
        if( NULL == setup ){
            sbuff= "bad FFTSetup in rfpix, exit...\n ";
            messageRF( sbuff, 2 );
            exit( EXIT_FAILURE );
        }
    }

    return( +1 );

};  // end rfpix::resize()

//--------------------- findRange() ----------------------------------
//  find range of real pix
//
//  return imag part for testing
//
void rfpix::findRange( float &rmin, float &rmax )
{
    int nxyt= nxl*nyl;
    float x;

    if( (nxl > 0) && (nyl > 0)  ){
        int i;
        rmin = rmax = rdata[0];
        //aimin = aimax = idata[0];
        for( i=0; i<nxyt; i++) {
           x = rdata[i];
           if( x < rmin ) rmin = x;
           if( x > rmax ) rmax = x;
           //x = idata[i];
           //if( x < aimin ) aimin = x;
           //if( x > aimax ) aimax = x;
        }  /* end for(i...) */

        return;
    }

};  // end rfpix::findRange()

/*------------------------- toString( int ) ----------------------*/
/*
    convert a number into a string
*/
std::string rfpix::toString( int i )
{
        std::stringstream ss;
        ss << i;
        return ss.str();

};  // end rfpix::toString( int )

