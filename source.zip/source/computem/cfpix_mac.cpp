/*              *** cfpix_mac.cpp ***

Alternate version for Apple Mac only
required link option:   -framework Accelerate

 ------------------------------------------------------------------------
Copyright 2012-2026 Earl J. Kirkland

This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

---------------------- NO WARRANTY ------------------
THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL THE AUTHOR BE LIABLE
FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
ANY OTHER PROGRAM). 

------------------------------------------------------------------------

    The Apple Arm CPU on the Macdoes not have a precision timer so FFTW
    cannot find the optimal FFT form and defaults to a slow FFT.
    The Apple Accelerate Framework has a faster FFT just for the Apple CPU
    but is only for powers of 2 (FFTW has all lengths).
    Make a special version of cfpix.cpp for the Apple Mac

   C++ class to manage complex floating point images (in ANSI-C++)

   collect (isolate) the FFT details here so it can be easily changed in future

   NOTE: the complex to real portion is only partially implemented because
         it is not used much - should fix this some time

The source code is formatted for a tab size of 4.

----------------------------------------------------------
The public member functions are:

nx()       : return x size of current image (in pixels)
ny()       : return y size of current image (in pixels)

re(ix,iy)  : return reference to real part of pixel at (ix,iy)
im(ix,iy)  : return reference to imag part of pixel at (ix,iy)

rre(ix,iy) : return reference to pixel at (ix,iy) of the
             real image for complex to real transform

fft()      :  perform FFT
ifft()     : inverse FFT

init()     : perform initialization
copyInit() : copy the initialization

resize()        : resize current in-memory image (current data may be lost)
findRange()     : find range of values in complex image

invert2D( )     : rearrange pix with corners moved to center (for FFT's)

operator*=() 
operator+=()
operator=()

----------------------------------------------------------

   started 9-june-2012 E. Kirkland
   move invert2D() to cfpix 21-nov-2012 ejk
   add messageCF() and remove most printf's 16-apr-2013 ejk
   add operator=() 11-jun-2013 ejk
   add string message 29-aug-2013 ejk
   update comments 7-sep-2014 ejk
   small change in operator+=() 25-oct-2015 ejk
   fix bug in invert2D() for unequal nx,ny 30-jul-2016 ejk
   remove c2r mode (now in rfpix) to simplify 12-aug-2025 ejk
   add alternate mac version 20-aug-2025 ejk
   remove nrxyl 7-nov-2025 ejk
   fix x/y order error in fft call 18-nov-2025 elk
   test vDSP_vsmul() in scaling (no sig. improvement) 31-dec-2025 ejk
   fix FFT directions 25-jan-2026 ejk
   last modified 25-jan2026 ejk
*/

#include "cfpix.hpp"    // class definition + inline functions here

#include <sstream>  // string streams
#include <cstdlib>

#include "slicelib.hpp"    // misc. routines for multislice

//------------------ constructor --------------------------------

cfpix::cfpix( int nx, int ny )
{
    nxl = nyl = 0;

    if( (nx > 0 ) && ( ny > 0 ) ) resize( nx, ny );

}  // end cfpix::cfpix()

//------------------ destructor ---------------------------------
cfpix::~cfpix()
{
    if( (nxl>0) && (nyl>0) ) {
        free( rdata );
        free( idata );
    }

    nxl = nyl = 0;
    lengthOK = 0;
    
}  // end cfpix::~cfpix()

//------------------ copyInit ---------------------------------
//  not needed on mac,  dummy return
void cfpix::copyInit( cfpix &xx)
{
    return;
    
}  // end cfpix::copyInit()


//------------------ forward transfrom ---------------------------------
void cfpix::fft()
{
    if( 0 == lengthOK ){
        sbuff= "cfpix fft invoked with length not a power of 2 (required by Apple):\n"
                +toString(nxl)+" x "+ toString(nxl);
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }

    cdata.realp = rdata;   /* store real,imag data pointers in Apple structure */
    cdata.imagp = idata;

    //   perform the complex in-place FFT 
    //    remember direction might be opposite of mine
    //vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Forward);
    vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Inverse);
    
}  // end cfpix::fft()

//------------------ inverse transfrom ---------------------------------
void cfpix::ifft()
{
    int ix, iy, j, nx, ny, nxyt=nxl*nyl;
    float scale;

    if( 0 == lengthOK ){
        sbuff= "cfpix ifft invoked with length not a power of 2 (required by Apple):\n"
                +toString(nxl)+" x "+ toString(nxl);
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }

    cdata.realp = rdata;   /* store real,imag data pointers in Apple structure */
    cdata.imagp = idata;

    //   perform the complex in-place FFT 
    //    remember direction might be oppposite of mine
    vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Forward);
    //vDSP_fft2d_zip( setup, &cdata, 1, 0, lny, lnx, kFFTDirection_Inverse);

    
    /*  multiplied by the scale factor */
    scale = 1.0F/( (float)(nxl * nyl) );

    #ifdef OLDCODE
    for( j=0; j<nxyt; j++) {
            rdata[j] *= scale;
            idata[j] *= scale; 
    } /* end for(j..) */
    #endif

    //  this didn't improve speed sig. amount (maybe 1%?) (31-dec-2025 ejk)
    vDSP_vsmul( rdata,  1, &scale, rdata, 1, nxyt );
    vDSP_vsmul( idata,  1, &scale, idata, 1, nxyt );

}  // end cfpix::ifft()

//------------------ initializer ---------------------------------
//
// not needed for Apple Accelerate
//  dummy return
void cfpix::init( int mode, int nthreads )
{
    return;

}  // end cfpix::initx()


/*------------------------- invert2D() ----------------------*/
/*
    rearrange pix with corners moved to center (a la FFT's)

    pix = complex image
    nx,ny = range of image 0<ix<(nx-1) and 0<iy<(ny-1)

*/
void cfpix::invert2D( )
{
    int ix, iy, i, j, ixmid, iymid;
    float t;

    ixmid = nxl/2;
    iymid = nyl/2;

    for( ix=0; ix<nxl; ix++) 
    for( iy=0; iy<iymid; iy++) {
        i = iy + ix*nyl;
        j = (iy+iymid) + ix*nyl;
        t = rdata[i];         // swap i and j positions
        rdata[i] = rdata[j]; 
        rdata[j] = t;
        t = idata[i];
        idata[i] = idata[j]; 
        idata[j] = t;
    }

    for( ix=0; ix<ixmid; ix++)
    for( iy=0; iy<nyl; iy++) {
        i = iy + ix*nyl;
        j = iy + (ix+ixmid)*nyl;
        t = rdata[i];         // swap i and j positions
        rdata[i] = rdata[j]; 
        rdata[j] = t; 
        t = idata[i];
        idata[i] = idata[j]; 
        idata[j] = t;
    }

}  // end invert2D()

/*------------------------- messageCF() ----------------------*/
/*
    common message output
    redirect all print message to here so this can be redirected
        to a dialog box in a GUI or cmd line 

   stemp[] = character string with message to disply
   level = level of seriousness
            0 = simple status message
        1 = significant warning
        2 = possibly fatal error
*/
void cfpix::messageCF( std::string &smsg,  int level )
{
    messageSL( smsg.c_str(), level );  //  just call slicelib version for now
}

//--------------------- operator+=() ----------------------------------
//   real data not implemented yet
cfpix& cfpix::operator+=( const cfpix& m  )
{
    if( (m.nxl != nxl) || (m.nyl != nyl)  ){
        sbuff= "cfpix += operator invoked with unequal sizes:\n"
                +toString(nxl)+" x "+ toString(nxl) +" and "
                + toString(m.nxl)+" x "+ toString( m.nxl );
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    } else if( (nxl>0) && (nyl>0) ){
        int i, nn=nxl*nyl;
        for( i=0; i<nn; i++) {
            rdata[i] += m.rdata[i];
            idata[i] += m.idata[i];
        }
    }
    return *this;
}  //  end cfpix::operator+=()

//--------------------- operator*=() ----------------------------------
//  element by element multiply
//   real data not implemented yet
cfpix& cfpix::operator*=( const cfpix& m  )
{
    int nxyt= nxl*nyl;

    if( (m.nxl != nxl) || (m.nyl != nyl)  ){
        sbuff= "cfpix operator*= invoked with unequal sizes:\n"
                +toString(nxl)+" x "+ toString(nxl) +" and "
                + toString(m.nxl)+" x "+ toString( m.nxl );
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    } else  if( (nxl>0) && (nyl>0) ) {
        int i;
        float wr, wi, tr, ti;
        for( i=0; i<nxyt; i++) {
           wr = rdata[i];   //  real part 
           wi = idata[i];   //  imag part 
           tr = m.rdata[i];
           ti = m.idata[i];
           rdata[i] = wr*tr - wi*ti;
           idata[i] = wr*ti + wi*tr;
        }  /* end for(i...) */
   } 
    return *this;
}  //  end cfpix::operator*=()

//--------------------- operator*=() ----------------------------------
//  multiply all elements by a constant
//   real data not implemented yet
cfpix& cfpix::operator*=( const float xf  )
{
    int i, nxyt= nxl*nyl;

    if(  (nxl>0) && (nyl>0) )
        for( i=0; i<nxyt; i++) {
           rdata[i] *= xf;
           idata[i] *= xf;
        }  // end for(i...)

    return *this;
}   //  end cfpix::operator*=()

//--------------------- operator=() ----------------------------------
//  element by element copy (only data not plan)
cfpix& cfpix::operator=( const cfpix& m  )
{
    int nxyt= nxl*nyl;

    if( (m.nxl != nxl) || (m.nyl != nyl)  ){
        sbuff= "cfpix operator= invoked with unequal sizes:\n"
                +toString(nxl)+" x "+ toString(nxl) +" and "
                + toString(m.nxl)+" x "+ toString( m.nxl );
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    } else if( (nxl>0) && (nyl>0) ) {

        for( int i=0; i<nxyt; i++) {
           rdata[i] = m.rdata[i];   //  real part 
           idata[i] = m.idata[i];   //  imag part
        }
    } else {
        sbuff= "bad operator=() in cfpix"; // gcc requires this step
        messageCF( sbuff, 2 );
        exit( EXIT_FAILURE );
    }

    return *this;

}     //  end  cfpix::operator=()

//--------------------- operator=() ----------------------------------
//  initial to a real value
//   real data not implemented yet
cfpix& cfpix::operator=( const float xf )
{
    int nxyt= nxl*nyl;

    if( (nxl > 0) && (nyl>0)  ) {
        int i;
        for( i=0; i<nxyt; i++) {
           rdata[i] = xf;      //  real part 
           idata[i] = 0.0F;    //  imag part
        }  /* end for(i...) */
    } else {
        resize( 1, 1 );    //  just do what we can...
        rdata[1] = xf;
        idata[1] = 0.0F;
    }

    return *this;
}     //  end  cfpix::operator=()

//------------------------- pwr2() ------------------------*/
//
//    return the nearest power of 2 greater than or equal to 
//    the argument
//    - from powerof2() in fft2dc.c
//
int cfpix::pwr2( int n )
{
        int ln;
        int n2;

        ln = 1;
        n2 = 2;
        while( (n2 < n) && (ln<25) ) { n2*=2; ln++; }

        return( n2 );
}


//--------------------- resize() ----------------------------------
//  resize data buffer 
//  note: existing data (if any) may be destroyed
//
int cfpix::resize( const int nx, const int ny )
{
    if( (nx != nxl) || (ny != nyl) ){
        if( (nxl != 0) && (nyl != 0) ) {
            free( rdata );
            free( idata );
            vDSP_destroy_fftsetup(setup); 
        }
        nxl = nx;
        nyl = ny;
        rdata = (float*) malloc( nx*ny* sizeof(float) );
        idata = (float*) malloc( nx*ny* sizeof(float) );

        if( (NULL == rdata) || (NULL == idata) ) {
            sbuff= "Cannot allocate image storage in cfpix::resize()";
            messageCF( sbuff, 2 );
            return( -1 );
        }
    
        lnx = (long) ( log( (double) nxl )/log(2.0) + 0.5 );
        lny = (long) ( log( (double) nyl )/log(2.0) + 0.5 );

        int nxTest = pwr2( nx );   // Apple length be a power of 2
        int nyTest = pwr2( ny );
        if( (nxTest == nx) && (nyTest == ny) && (nx <= 1024) && (ny <= 1024) ) 
            lengthOK = 1;
        else lengthOK = 0;
        
        setup = vDSP_create_fftsetup(MAX(lnx, lny), FFT_RADIX2);
        if( NULL == setup ){
            sbuff= "bad FFTSetup in cfpix, exit...\n ";
            messageCF( sbuff, 2 );
            exit( EXIT_FAILURE );
        }
    }

    return( +1 );

};  // end cfpix::resize()

//--------------------- findRange() ----------------------------------
//  find range of complex pix
//
void cfpix::findRange( float &rmin, float &rmax, float &aimin, float &aimax )
{
    int nxyt= nxl*nyl;
    float x;

    if( (nxl > 0) && (nyl > 0)  ){
        int i;
        rmin = rmax = rdata[0];
        aimin = aimax = idata[0];
        for( i=0; i<nxyt; i++) {
           x = rdata[i];
           if( x < rmin ) rmin = x;
           if( x > rmax ) rmax = x;
           x = idata[i];
           if( x < aimin ) aimin = x;
           if( x > aimax ) aimax = x;
        }  /* end for(i...) */

        return;
    }

};  // end cfpix::findRange()

/*------------------------- toString( int ) ----------------------*/
/*
    convert a number into a string
*/
std::string cfpix::toString( int i )
{
        std::stringstream ss;
        ss << i;
        return ss.str();

};  // end autostem::toString( int )

