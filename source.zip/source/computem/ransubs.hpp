/*      *** ransubs.h ***

------------------------------------------------------------------------
Copyright 2024 Earl J. Kirkland

This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

---------------------- NO WARRANTY ------------------
THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
IN NO EVENT SHALL THE AUTHOR BE LIABLE
FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
ANY OTHER PROGRAM).
------------------------------------------------------------------------

        Some simple random number generators

    ranflat()     : return a random number with uniform distribution
    rangauss()    : return a random number with Gaussian distribution
    ranPoisson()  : return a random number with Poisson distribution

    getInitSeed() : diagnostic
    resetSeed()   : diagnostic - should not normally use this

    move RNG from slicelib to here
    to protect the seed instead of awkwardly passing it around


    started 23-dec-2023 E. Kirkland
    update resetSeed() to return void  11-jun-2024 ejk
    last modified 11-jun-2024 ejk
*/


#ifndef RANSUBS_HPP   // only include this file if its not already

#define RANSUBS_HPP   // remember that this has been included

#include <cmath>


//------------------------------------------------------------------
class ransubs {

public:

    ransubs(int iseed0=0 );         // constructor functions

    ~ransubs();        //  destructor function

    // <0 indicates a bad init
    long getInitSeed() { return initseed;  }

    /*---------------------------- ranflat -------------------------------*/
    /*  from slicelib 23-dec-2023 ejk

        return a random number in the range 0.0->1.0
        with uniform distribution

        the 'Magic Numbers' are from
            Numerical Recipes 2nd edit pg. 285
    */
    inline double ranflat()
    {
        static unsigned long a = 1366, c = 150889L, m = 714025L;
        iseed = (a * (iseed) + c) % m;
        return(((double)iseed) / m);
    }  // end ransubs::ranflat()

    double rangauss();

    int ranPoisson(double mean);

    void resetSeed( int newSeed ) { iseed = (unsigned long) newSeed; }

private:

    unsigned long iseed;
    long initseed;
 
}; // end ransubs::


#endif