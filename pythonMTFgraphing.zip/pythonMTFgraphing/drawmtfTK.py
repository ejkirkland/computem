#
#  drawmtfTK.py
#
#------------------------------------------------------------------------
#Copyright 2017-2021 Earl J. Kirkland
#
#This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  using python(x,y) ; python 3.8
#
#  NOTE: the scipy adaptive integrator may fail for some
#   unusual combinations of parameter (STEM)
#
#  Remember:  ttk.comboBox() events occur at useable times
#    so have to use a memu!
#
#  started 19-jun-2017 ejk
#  menu and buttons working 25-jun-2017 ejk
#  BF graph ok 27-jun-2017 ejk
#  working 5-jul-2017 ejk
#  add default file extension in save-as and disable
#       defocus spread in STEM for speed 8-jul-2017 ejk
#  fix typo in Cs5 units (no change in calc.) 8-jan-2018 ejk
#  update to python 3.8, make graph a little bigger 
#     and remove nxw,nyw(not used)25-dec-2021 ejk
#  last modified 25-dec-2021 ejk
#
import tkinter
import tkinter, tkinter.constants, tkinter.filedialog, tkinter.messagebox

from numpy import *
from scipy import *
from pylab import *
from ctemh import *
from stemh import *

#nxpixels=680  # old size of graph in pixels
#nypixels=300

nxpixels=820  # size of graph in pixels
nypixels=380

nxsize = nxpixels+20  # size of canvas in pixels
nysize = nypixels+180

nxo = 35       # position of origin in pixels
nyo = 200

npoints = 400    # number of points in graph
NS= 400  # number of sampling points

MTFmin = -1
MTFmax = +1
MTFo = 0
kmax = 1.2
rmax = 4.0
PROBEmin = -1
PROBEmax = +1
PROBEo = 0.0

iBF = 0   #  mode constants
iADF = 1
iPROBE = 2

NPARAM = 7
iDF = 0
iCS = 1
iKEV = 2
iDDF = 3
iBETA = 4
iOBJAP = 5
iCs5 = 6

class myApp( tkinter.Tk ):

    mode = 0   # current selections
    iparam = 0

    kpos = linspace( 0., kmax, npoints )
    rpos = linspace( 0.0, rmax, npoints )
    # remember; drawmtf and ctemh have different order!!
    param = [  800.0, 1.3, 100, 50, 0.1, 10.0, 0.0 ]
    BFgraphParam = [  0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ]
    ADFgraphParam = [   0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.00 ]
    PROBEgraphParam = [   0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 ]

    def __init__(self, parent):
        tkinter.Tk.__init__(self,parent)
        self.parent = parent
        self.initialize()
        self.mode = iBF
        self.update()

    def initialize(self):
        self.grid()

        # ----- make menus -----------
        top = self.winfo_toplevel()
        self.menubar = tkinter.Menu( top )
        # -----  file menu
        self.fileMenu = tkinter.Menu( self.menubar, tearoff=0 )
        self.fileMenu.add_command( label="save-as", command=self.FileSave)
        self.fileMenu.add_cascade( label="about", command=self.FileAbout)
        self.fileMenu.add_cascade( label="exit", command=self.FileExit)
        self.menubar.add_cascade(label='file', menu=self.fileMenu)
        # -----  mode menu
        self.modeMenu = tkinter.Menu( self.menubar, tearoff=0 )
        self.modeMenu.add_command( label="BF-CTEM mtf", command=self.BFmode)
        self.modeMenu.add_cascade( label="ADF-STEM mtf", command=self.ADFmtfmode)
        self.modeMenu.add_cascade( label="STEM-Probe", command=self.ADFprbmode)
        self.menubar.add_cascade(label='mode', menu=self.modeMenu)
        # ----- parameter menu
        self.paramMenu = tkinter.Menu( self.menubar, tearoff=0 )
        self.paramMenu.add_command( label='defocus (Ang)', command=self.parmdf)
        self.paramMenu.add_cascade( label='Cs (mm)', command=self.paramCs)
        self.paramMenu.add_cascade( label='keV', command=self.paramkev)
        self.paramMenu.add_command( label='defocus spread (Ang)', command=self.paramddf)
        self.paramMenu.add_cascade( label='cond. angle (mrad)', command=self.paramBeta)
        self.paramMenu.add_cascade( label='obj. angle (mrad)', command=self.paramAlpha)
        self.paramMenu.add_cascade( label='Cs5 (mm)', command=self.paramCs5)
        self.menubar.add_cascade(label='param', menu=self.paramMenu)

        top.config(menu=self.menubar)

        # ------ make mode name box
        self.modeNameValue = tkinter.StringVar()
        self.modeNameValue.set("BF-CTEM mtf")
        self.modeName = tkinter.Label(self, textvariable=self.modeNameValue, width=20)
        self.modeNameValue.set("BF-CTEM mtf")
        self.modeName.grid( column=0, row=0)

        # ------ make parameter name box
        self.paramNameValue = tkinter.StringVar()
        self.paramNameValue.set("defocus (Ang)")
        self.paramName = tkinter.Entry(self, textvariable=self.paramNameValue)
        self.paramName.grid( column=1, row=0)

        # ------ make parameter value box
        self.paramValue = tkinter.StringVar()
        self.paramValue.set(self.param[iDF])
        self.entry = tkinter.Entry(self, textvariable=self.paramValue)
        self.entry.bind( '<Return>', self.ParamReturn )
        self.entry.grid(column=2,row=0 )

        # ----- make up button
        self.bup = tkinter.Button( self, text="up", command=self.OnbUp )
        self.bup.grid(column=3,row=0)

        # ----- make down button
        self.bdown = tkinter.Button( self, text="down", command=self.OnbDown)
        self.bdown.grid(column=4,row=0)

        # ------- make a canvas to draw in
        self.canv = tkinter.Canvas( self, width=nxsize, height=nysize,
                         bg='white' )
        self.canv.grid( column=0, row=2, columnspan=5 )

        self.grid_columnconfigure(0,weight=1)
        self.resizable(True,False)

    def OnbUp(self):
        #print "bUp"  # diagnostic
        if abs( self.param[self.iparam] ) < 1.0e-5 :
            self.param[self.iparam] += 0.05
        else:
            self.param[self.iparam] *= 1.05
        i = self.iparam  # make next line shorter
        if i == iKEV or i == iDDF or i == iBETA or i == iOBJAP :
            self.param[self.iparam] =  abs ( self.param[self.iparam] )
        self.paramValue.set( self.param[self.iparam] )
        self.update()

    def OnbDown(self):
        #print "bDown"  # diagnostic
        if abs( self.param[self.iparam] ) < 1.0e-5 :
            self.param[self.iparam] -= 0.05
        else:
            self.param[self.iparam] /= 1.05
        i = self.iparam  # make next line shorter
        if i == iKEV or i == iDDF or i == iBETA or i == iOBJAP :
            self.param[self.iparam] =  abs ( self.param[self.iparam] )
        self.paramValue.set( self.param[self.iparam] )
        self.update()

    #-------  file menu items
    def FileSave(self):
        self.saveFile = tkinter.filedialog.asksaveasfilename( title = "Select file",
                filetypes = (("png files","*.png"),("pdf files","*.pdf"),
                             ("all files","*.*")),
                defaultextension='.png')
        #print "file-save = ", self.saveFile  #  diagnostic
        if self.mode == iBF :
            figure( 1 )
            clf
            x = [0, kmax]		 # plot line through zero
            y = [0, 0]
            plot( self.kpos, self.BFypts, 'k-', x, y, 'k--'  )
            axis([0, kmax, -1, +1])
            xlabel( 'Spatial Frequency (in 1/A)')
            ylabel( 'MTF' )
            s1 = 'E= %gkeV, Cs3= %gmm, Cs5= %gmm, df= %gA, ' % (
                self.BFgraphParam[iKEV], self.BFgraphParam[iCS],
                self.BFgraphParam[iCs5], self.BFgraphParam[iDF] )
            s2 = 'CA= %gmr, ddf= %gA' % (self.BFgraphParam[iBETA],
                                         self.BFgraphParam[iDDF])
            title( s1+s2 )
            savefig( self.saveFile )
            #show()
            close()
        elif self.mode == iADF :
            figure( 1 )
            clf
            plot( self.kpos, self.amtf )
            #axis([0, kmax, -1, +1])
            xlabel( 'k (inv. Angs.)' )
            ylabel( 'MTF' )
            s1 = 'Cs3= %gmm, Cs5= %gmm, ' % ( self.ADFgraphParam[iCS],
                                             self.ADFgraphParam[iCs5] )
            s2 = ' df= %gA, ' %  (self.ADFgraphParam[iDF] )
            s3 = 'E= %gkeV, OA= %gmrad, ' % ( self.ADFgraphParam[iKEV],
                                             self.ADFgraphParam[iOBJAP] )
            s4 = 'ddf= %gA' % (self.ADFgraphParam[iDDF])
            title( s1 + s2 + s3 + s4 )
            savefig( self.saveFile  )
            #show()
            close()
        elif self.mode == iPROBE :
            figure( 1 )
            clf
            plot( self.rpos, self.apsf )
            #axis([0, rmax, -1, +1])
            xlabel( 'radius in Angstroms')
            ylabel( 'PSF' )
            s1 = 'Cs3= %gmm, Cs5= %gmm, ' % (self.PROBEgraphParam[iCS],
                                             self.PROBEgraphParam[iCs5] )
            s2 = 'df= %gA, ' % ( self.PROBEgraphParam[iDF] )
            s3 = 'E= %gkeV, OA= %gmrad, ' % (self.PROBEgraphParam[iKEV],
                                             self.PROBEgraphParam[iOBJAP])
            s4 = 'ddf= %gA' % (self.PROBEgraphParam[iDDF])
            title( s1+s2+s3+s4)
            savefig( self.saveFile )
            #show()
            close()

    def FileAbout(self):
        tkinter.messagebox.showinfo( "about drawmtf",
             "This program is provided AS-IS with ABSOLUTELY NO WARRANTY\n "
            +"under the GNU general public license.\n\n"
            + "1. defocus spread is disabled in STEM for speed \n"
            + "2. scipy integration may fail with large OA and large df etc.\n"
            + "3. enter only numbers for the parameters\n"
            +  "\nversion dated 24-dec-2021"  )

    def FileExit(self):
        top = self.winfo_toplevel()
        top.destroy()

    #-------  mode menu items
    def BFmode(self):
        self.modeNameValue.set("BF-CTEM mtf")
        self.mode = iBF
        #print "BFmode"  # diagnostic
        self.update()

    def ADFmtfmode(self):
        self.modeNameValue.set("ADF-STEM mtf")
        self.mode = iADF
        #print "ADFmtfmode"  # diagnostic
        self.update()

    def ADFprbmode(self):
        self.modeNameValue.set("STEM-Probe")
        self.mode = iPROBE
        #print "ADFprbmode"  # diagnostic
        self.update()

    #-------  param menu items
    def parmdf(self):
        self.paramNameValue.set("defocus (Ang)")
        self.paramValue.set(self.param[0])
        self.iparam = iDF
        #print "defocus (Ang)"  # diagnostic

    def paramCs(self):
        self.paramNameValue.set("Cs (mm)")
        self.paramValue.set(self.param[1])
        self.iparam = iCS
        #print "Cs (mm)"  # diagnostic

    def paramkev(self):
        self.paramNameValue.set("kev")
        self.paramValue.set(self.param[2])
        self.iparam = iKEV
        #print "kev"  # diagnostic

    def paramddf(self):
        self.paramNameValue.set("defocus spread (Ang)")
        self.paramValue.set(self.param[3])
        self.iparam = iDDF
        #print "ddf"  # diagnostic

    def paramBeta(self):
        self.paramNameValue.set("cond. angle (mrad)")
        self.paramValue.set(self.param[4])
        self.iparam = iBETA
        #print "cond angle"  # diagnostic

    def paramAlpha(self):
        self.paramNameValue.set("obj. angle (mm)")
        self.paramValue.set(self.param[5])
        self.iparam = iOBJAP
        #print "obj. angle"  # diagnostic

    def paramCs5(self):
        self.paramNameValue.set("Cs5 (mm)")
        self.paramValue.set(self.param[6])
        self.iparam = iCs5
        #print "Cs5"  # diagnostic

    #----- Param Entry event
    def ParamReturn( self, event ):
        #print "parma-entry param,mode= ", self.iparam, self.mode
        #print "value = ", self.entry.get()
        #self.param[self.iparam] = float(self.entry.get())  # bad
        self.param[self.iparam] = float(self.paramValue.get())
        self.update()

    #-------------- update() ----------------------
    def update( self ):
        if self.mode == iBF :
            self.makeBFgraph()
            self.makePlot()
        elif self.mode == iADF :
            self.makeADFgraph()
            self.makePlot()
        elif self.mode == iPROBE :
            self.makePROBEgraph()
            self.makePlot()

    # ----------  draw graphs ------------------
    def makePlot(self):

        self.canv.delete( "all" )  #  clear the screen

        #  draw axis
        l = self.canv.create_line( nxo, nyo, nxo+nxpixels, nyo )
        l = self.canv.create_line( nxo, nyo-nypixels/2-20, nxo, nyo+nypixels/2+20 )

        #  draw graphs
        #---------- BF MTF ---------------------
        if self.mode == iBF :
            self.canv.create_text(  nxo+nxpixels-75, nyo-20, text="k (in 1/A)" )
            scalex = nxpixels/kmax
            scaley = nypixels/(MTFmax-MTFmin)

            nx = nxo + (int) ( self.kpos[0] * scalex )
            ny = nyo - (int) ( (self.BFypts[0] - MTFo) * scaley)
            for i in range(1, npoints):
                nx2 = nxo + ( self.kpos[i] * scalex )
                ny2 = nyo - ( (self.BFypts[i] - MTFo) * scaley)
                self.canv.create_line( nx, ny, nx2, ny2 )
                nx = nx2
                ny = ny2

            s = "%7f" % self.BFgraphParam[iKEV]
            self.canv.create_text( nxo+100, nyo+nypixels/2+40,
                    text= s + " keV", justify=tkinter.RIGHT )

            s = "%7f" % self.BFgraphParam[iCS]
            self.canv.create_text(  nxo+100, nyo+nypixels/2+60,
                 text= "Cs = " + s + " mm.")

            s = "%7f" % self.BFgraphParam[iDF]
            self.canv.create_text( nxo+100, nyo+nypixels/2+80,
                        text= "defocus = " + s + " A" )

            s = "%7f" % self.BFgraphParam[iBETA]
            self.canv.create_text( nxo+300, nyo+nypixels/2+40,
                    text= "cond. angle = " + s + " mrad" )

            s = "%7f" %  self.BFgraphParam[iDDF]
            self.canv.create_text( nxo+300, nyo+nypixels/2+60,
                    text= "defocus spread = " + s + " A" )

            s = "%7f" %  self.BFgraphParam[iCs5]
            self.canv.create_text( nxo+300, nyo+nypixels/2+80,
                    text= "Cs5 = " + s + " mm." )

        #---------- ADF MTF ---------------------
        elif self.mode == iADF :
            self.canv.create_text(  nxo+nxpixels-75, nyo-20, text="k (in 1/A)" )
            scalex = nxpixels/kmax
            scaley = nypixels/(MTFmax-MTFmin)

            nx = nxo + int( self.kpos[0] * scalex )
            ny = nyo - int( (self.amtf[0] - MTFo) * scaley )
            for i in range(1, npoints):
                nx2 = nxo + ( self.kpos[i] * scalex )
                ny2 = nyo - ( (self.amtf[i] - MTFo) * scaley)
                self.canv.create_line( nx, ny, nx2, ny2 )
                nx = nx2
                ny = ny2

            s = "%7f" % self.ADFgraphParam[iKEV]
            self.canv.create_text( nxo+100, nyo+nypixels/2+40,
                    text= s + " keV", justify=tkinter.RIGHT )

            s = "%7f" % self.ADFgraphParam[iCS]
            self.canv.create_text(  nxo+100, nyo+nypixels/2+60,
                 text= "Cs = " + s + " mm.")

            s = "%7f" % self.ADFgraphParam[iDF]
            self.canv.create_text( nxo+100, nyo+nypixels/2+80,
                        text= "defocus = " + s + " A" )

            s = "%7f" % self.ADFgraphParam[iOBJAP]
            self.canv.create_text( nxo+300, nyo+nypixels/2+40,
                    text= "obj. angle = " + s + " mrad" )

            s = "%7f" %  self.ADFgraphParam[iDDF]
            self.canv.create_text( nxo+300, nyo+nypixels/2+60,
                    text= "defocus spread = " + s + " A" )

            s = "%7f" %  self.ADFgraphParam[iCs5]
            self.canv.create_text( nxo+300, nyo+nypixels/2+80,
                    text= "Cs5 = " + s + " mm." )

        #---------- ADF MTpsfF ---------------------
        elif self.mode == iPROBE :
            #print "mode = ", self.mode
            self.canv.create_text(  nxo+nxpixels-75, nyo-10, text="r (in A)" )
            scalex = nxpixels/rmax
            scaley = nypixels/(PROBEmax-PROBEmin)

            nx = nxo + int( self.rpos[0] * scalex )
            ny = nyo - int( (self.apsf[0] - PROBEo) * scaley)
            for i in range( 1, NS ):
                if self.rpos[i] < rmax :
                    nx2 = nxo + int( self.rpos[i] * scalex )
                    ny2 = nyo - int( (self.apsf[i] - PROBEo) * scaley)
                    self.canv.create_line( nx, ny, nx2, ny2 )
                    nx = nx2
                    ny = ny2

            s = "%7f" % self.PROBEgraphParam[iKEV]
            self.canv.create_text( nxo+100, nyo+nypixels/2+40,
                    text= s + " keV", justify=tkinter.RIGHT )

            s = "%7f" % self.PROBEgraphParam[iCS]
            self.canv.create_text(  nxo+100, nyo+nypixels/2+60,
                 text= "Cs = " + s + " mm.")

            s = "%7f" % self.PROBEgraphParam[iDF]
            self.canv.create_text( nxo+100, nyo+nypixels/2+80,
                        text= "defocus = " + s + " A" )

            s = "%7f" % self.PROBEgraphParam[iOBJAP]
            self.canv.create_text( nxo+300, nyo+nypixels/2+40,
                    text= "obj. angle =  = " + s + " mrad" )

            s = "%7f" %  self.PROBEgraphParam[iDDF]
            self.canv.create_text( nxo+300, nyo+nypixels/2+60,
                    text= "defocus spread = " + s + " A" )

            s = "%7f" %  self.PROBEgraphParam[iCs5]
            self.canv.create_text( nxo+300, nyo+nypixels/2+80,
                    text= "Cs5 = " + s + " mm" )

            s = "%7f" %  self.fwhmii
            self.canv.create_text( nxo+300, nyo+nypixels/2+100,
                    text= "FWHM-II =  = " + s + " A" )

        # ------------- label axis
        if self.mode == iBF or self.mode == iADF :
            #print 'axis = '   #  diagnostic
            ny = nyo - ( (int) (scaley*MTFmax + 0.5) )
            self.canv.create_line( nxo-5, ny, nxo+5, ny )
            self.canv.create_text(  nxo-30, ny+5, text= MTFmax  )

            ny = nyo -  (scaley*MTFmin + 0.5)
            self.canv.create_line( nxo-5, ny, nxo+5, ny )
            self.canv.create_text(  nxo-30, ny+5, text= MTFmin  )
            dk = 0.1
            ny = int(kmax/dk)
            for i  in range(1, ny) :
                k = dk*i
                nx = nxo + ( (int) (k*scalex + 0.5 ) )
                self.canv.create_line( nx, nyo-5, nx, nyo+5 )
                s = "%4.2f" % k
                self.canv.create_text(  nx-10, nyo+20, text=s )

        elif self.mode == iPROBE :
            ny = nyo - ( (int) (scaley*PROBEmax + 0.5) )
            self.canv.create_line( nxo-5, ny, nxo+5, ny )
            self.canv.create_text(nxo-30, ny+5, text= PROBEmax )

            ny = nyo - ( (int) (scaley*PROBEmin + 0.5) )
            self.canv.create_line( nxo-5, ny, nxo+5, ny )
            self.canv.create_text( nxo-30, ny+5, text= PROBEmin )

            dr = 0.5
            ny = ((int)(rmax/dr))
            for i in range(1, ny) :
                r = dr*i;
                nx = nxo + ( (int) (r*scalex + 0.5 ) )
                self.canv.create_line( nx, nyo-5, nx, nyo+5 )
                s = "%4.2f" % r
                self.canv.create_text( nx-10, nyo+20, text= s )

    # ----------  calculate graphs ------------------
    def makeBFgraph(self):
        changed = 0
        for i in range(0,NPARAM):

            if i != iOBJAP :
                if( abs( self.param[i] - self.BFgraphParam[i] ) >
                    1.0e-4 * abs( self.param[i] + self.BFgraphParam[i] ) ):
                    changed = 1

            self.BFgraphParam[i] = self.param[i]

        if changed > 0 :
            p = [ self.BFgraphParam[iKEV], self.BFgraphParam[iCS],
                self.BFgraphParam[iCs5], self.BFgraphParam[iDF],
                self.BFgraphParam[iDDF], self.BFgraphParam[iBETA],
                    0.0 ]
            # remember; drawmtf and ctemh have different order!!
            self.BFypts = ctemh( self.kpos, p, 0 )  #  the calculation

    #-------------------------
    def makeADFgraph(self):
        changed = 0
        for i in range(0,NPARAM):

            if i != iBETA and i != iDDF:
                if( abs( self.param[i] - self.ADFgraphParam[i] ) >
                    1.0e-4 * abs( self.param[i] + self.ADFgraphParam[i] ) ):
                    changed = 1

            self.ADFgraphParam[i] = self.param[i]

        # disable defocus spread for speed
        self.ADFgraphParam[iDDF] = 0.0

        if changed > 0 :
            p = [ self.ADFgraphParam[iKEV], self.ADFgraphParam[iCS],
                self.ADFgraphParam[iCs5], self.ADFgraphParam[iDF],
                self.ADFgraphParam[iOBJAP], self.ADFgraphParam[iDDF],
                    0.0 ]
            # remember; drawmtf and ctemh have different order!!
            self.amtf = stemhk( self.kpos, p )  #  the calculation

    #-------------------------
    def makePROBEgraph(self):
        changed = 0
        for i in range(0,NPARAM):

            if i != iBETA and i != iDDF :
                if( abs( self.param[i] - self.PROBEgraphParam[i] ) >
                    1.0e-4 * abs( self.param[i] + self.PROBEgraphParam[i] ) ):
                    changed = 1

            self.PROBEgraphParam[i] = self.param[i]

        # disable defocus spread for speed
        self.PROBEgraphParam[iDDF] = 0.0

        if changed > 0 :           
            p = [ self.PROBEgraphParam[iKEV], self.PROBEgraphParam[iCS],
                self.PROBEgraphParam[iCs5], self.PROBEgraphParam[iDF],
                self.PROBEgraphParam[iOBJAP], self.PROBEgraphParam[iDDF],
                    0.0 ]
            # remember; drawmtf and stemhr have different order!!
            self.apsf = stemhrCc( self.rpos, p )  #  the calculation
            self.fwhmii = prbsize(  self.rpos, self.apsf ) # probe size


app = myApp(None)
app.title('drawmtf')
app.mainloop()


