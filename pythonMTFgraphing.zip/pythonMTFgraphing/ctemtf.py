#
#  ctemtf.py
#
#  plot CTEM transfer functions
#
#------------------------------------------------------------------------
#Copyright 2011-2021 Earl J. Kirkland
#
#This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  started 23-jun-2011 ejk
#  small comsmetic changes 30-jun-2014 ejk
#  update to python 3.8 on 23-dec-2021 ejk
#  last modified 23-dec-2021 ejk
#
import numpy as np
import matplotlib.pyplot as plt
#from  math import *
from ctemh import *

print( 'Plot CTEM transfer function' )
cc = 'm'
while( cc in [ 'm', 'M' ]  ) :
    kev  = float( input('Type electron energy in keV : ') )
    Cs3  = float( input('Type spherical aberration Cs3 in mm : ') )
    Cs5  = float( input('Type spherical aberration Cs5 in mm : '))
    df   = float( input('Type defocus df in Angstroms : ') )
    ddf  = float( input('Type defocus spread ddf in Angs. : ') )
    beta = float( input('Type illumination semiangle in mrad : ') )
    p = np.array( [ kev, Cs3, Cs5, df, ddf, beta], float )
    #
    wav = wavelen(kev)  # electron wavelength
    Cs = max( 0.1, abs(Cs3) )
    #
    ds = np.sqrt( np.sqrt( Cs*1.0e7*wav*wav*wav ))
    kmax = 2.5/ds
    k = np.linspace( 0., kmax, 500 )  # 500 points to plot
    sinw = ctemh( k, p, 0 )        # transfer function
    x = [0, kmax]		 # plot line through zero
    y = [0, 0]
    fig, axs = plt.subplots( 1,1, figsize=(8,6), dpi=100)
    axs.plot( k, sinw, 'k-', x, y, 'k--'  )
    axs.axis([0, kmax, -1, +1])
    axs.set_xlabel( 'Spatial Frequency (in 1/A)')
    axs.set_ylabel( 'MTF' )
    s1 = 'E= %gkeV, Cs3= %gmm, Cs5= %gmm, df= %gA, ' % (kev, Cs3, Cs5, df )
    s2 = 'CA= %gmr, ddf= %gA' % (beta, ddf)
    axs.set_title( s1+s2 )
    #savefig( 'ctemtf.eps' )  # select file format
    plt.savefig( 'ctemtf.pdf' )
    plt.show()
    cc = input('ctemtf done, type m to continue : ')

