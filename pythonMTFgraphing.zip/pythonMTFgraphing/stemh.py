#
# ------- stemh.py -------------
#
#------------------------------------------------------------------------
#Copyright 2011-2022 Earl J. Kirkland
#
#This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  functions:
#
#   wavelen() return electron wavelength
#   stemhr()  calculate ADF-STEM probe PSF
#   stemhk()  calculate ADF-STEM probe MTF
#   lenr,i()  aberration function to integrate
#
#  started 25-jun-2011 E. Kirkland
#  stemhr() working 29-jun-2011 ejk
#  add stemhk() 29-jun-2011, works 2-jul-2011  ejk
#  small cosmetic changes 30-jun-2014 ejk
#  add probe size 8-jul-2014 ejk
#  add chromatic stemhrCc() Cc = ddf integration
#       9,10-jul-2014 ejk
#  update comments 31-jan-2015 ejk
#  update to python 3.8 on 23-dec-2021 ejk
#  removed global var. 25-dec-2021 ejk
#  convert to lensr(), lensi() to use cfunc() and 
#       J0 for quad() = much faster 4-jan-2022 ejk
#  last modified 4-feb-2022 ejk
#
import numpy as np
from scipy.special import jv     # for j0()
from scipy.integrate import quad   # for quad
from numba import cfunc, njit
#import numba_special   #  for jv() in lenr() and leni() - must be installed

from scipy import LowLevelCallable
from numba.types import intc, CPointer, float64

#-------- wavelength() ----------------
#
# electron wavelength for energy kev
def wavelen(kev):
    return( 12.3986/np.sqrt((2*511.0+kev)*kev) )

#
#-------- stemhr() ----------------
#
# function stemhr to calculate
#            STEM probe profile vs. r
#    input array r has the radial positions (in Angs.)
#    input variable params has the optical parameters
#    output array contains the psf
#
#  params = [kev, Cs3, Cs5, df, amax ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#
def stemhr( r, params ):
    kev = params[0]
    Cs3 = params[1]*1.0e7
    Cs5 = params[2]*1.0e7
    df = params[3]
    amax = params[4]*0.001
    wav = wavelen(kev)  # electron wavelength
    kmax = amax/wav
    w2 = wav*np.pi*df
    w4 = 0.5*np.pi*Cs3*wav*wav*wav
    w6 = np.pi*Cs5*wav*wav*wav*wav*wav /3.0
    nr = len( r )
    psf = np.empty(nr, float) # make array to fill
    for ir in range(0, nr, 1):
        intr = 2*np.pi*r[ir]
        # use adaptive quadrature because integrand
        #     not well behaved
        #hrr= quad( lensr.ctypes, 0, kmax, args=(w2, w4, w6, intr) )
        #hri= quad( lensi, 0, kmax, args=(w2, w4, w6, intr) )
        hrr= quad( LowLevelCallable(lensr.ctypes), 0, \
                  kmax, args=(w2, w4, w6, intr) )
        hri= quad( LowLevelCallable(lensi.ctypes), 0, \
                  kmax, args=(w2, w4, w6, intr) )
        psf[ir] = hrr[0]*hrr[0] + hri[0]*hri[0]

    a = max(psf)
    psf = psf/a  # norm. probe intensity to a max. of 1
    return psf

#
#-------- stemhrCc() ----------------
#
# function stemhrCc to calculate
#       STEM probe profile vs. r including chromatic aber.
#    input array r has the radial positions (in Angs.)
#    input variable params has the optical parameters
#    output array contains the psf
#
#  params = [kev, Cs3, Cs5, df, amax, ddf ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#  ddf  = FWHM of defocus spread (in Angstroms)
#
# Gauss-Hermite Quadrature
#       with exp(-x*x) weighting of integrand
#       from Abramowitz and Stegun, and Numerical Recipes
#
def stemhrCc( r, params ):
    NGH = 9  # number of Gauss-Hermete coeff. to use
    # absiccas and weights for Gauss-Hermite Quadrature
    xGH= np.array([ 3.190993201781528, 2.266580584531843, 1.468553289216668, \
        0.723551018752838, 0.000000000000000, -0.723551018752838, \
        -1.468553289216668,-2.266580584531843,-3.190993201781528] )
    wGH= np.array( [3.960697726326e-005, 4.943624275537e-003 , \
        8.847452739438e-002, 4.326515590026e-001, 7.202352156061e-001, \
        4.326515590026e-001,  8.847452739438e-002, 4.943624275537e-003, \
        3.960697726326e-005] )

    df0 = params[ 3 ]   #  defocus mean
    ddf = params[ 5 ]   # defocus spread FWHM in Angst.

    #  no defocus integration with small df spread
    if( ddf < 1.0 ):
        psf = stemhr( r, params )
        a = max(psf)
        psf = psf/a  # norm. probe intensity to a max. of 1
        return psf

    nr = len( r )
    psf = np.empty(nr, float) # make array to fill
    psf = 0

    #  integrate over defocus spread
    ndf = NGH
    ddf2 = np.sqrt(np.log(2.0)/(ddf*ddf/4.0))  # convert from FWHM
    for idf in range(0, ndf, 1):
        df = df0 + xGH[idf]/ddf2
        weight =  wGH[idf]
        #print "df step ", idf, " df= ", df  # debug
        params[3] = df
        psf1 = stemhr( r, params )
        a = sum( psf1 * r )  # normalize to total current
        psf = psf + weight*psf1/a

    params[ 3 ] = df0    #  restore original value
    a = max(psf)
    psf = psf/a  # norm. probe intensity to a max. of 1
    return psf

#
#-------- prbsize() ----------------
#
# function prbsize() to calculate
#       FWHM-II size from results stemhr()
#       II = integrated intensity meaning diameter of half current
#    input array r has the radial positions (in Angs.)
#    input array psf has probe intensity from stemhr()
#    output is the size
#
def prbsize( r, psf ):
    nr = len( r )
    psf2 = np.copy(psf)  # make new array to work with
    psf2[0] = psf2[0] * r[0]
    for ir in range(1, nr, 1):  # integrated intensity
        psf2[ir] = psf2[ir-1] + psf2[ir]*r[ir]

    amax = 0.5 * psf2[nr-1]  # should be half max. value
    for ir in range(nr-1, 0, -1):
        j = ir
        if( psf2[ir] < amax ) :
            break

    if( j <= 1 ):
        return 2.0*r[1]  # avoid divide by zero below

    #  interpolate to get a little more accurate
    d = abs( (r[j+1]-r[j])*(amax-psf2[j])/(psf2[j+1]-psf2[j]) )
    return 2.0*( r[j] + d)


#
#-------- stemhk() ----------------
#
#   function to calculate STEM mtf vs. k
#    input array k has the spatial freq. (in inv. Angs.)
#    input variable params has the optical parameters
#          [Cs, df, kev, amax] as elements
#    output array contains the transfer function
#
#  params = [kev, Cs3, Cs5, df, amax, ddf ]
#
#  kev  = electron energy (in keV)
#  Cs3  = third order spherical aberration (in mm)
#  Cs5  = fifth order spherical aberration (in mm)
#  df   = defocus (in Angstroms)
#  amax = objective aperture  (in mrad)
#  ddf  = FWHM of defocus spread (in Angstroms)
#
def stemhk( k, params ):
    kev = params[0]
    Cs3 = params[1]*1.0e7
    #  first calculate the psf using stemhr()
    nr = 500  # number of points in integral over r
    wav = wavelen(kev)  # electron wavelength
    Cs = max( 0.1e7, abs(Cs3) )
    rmax = 2.0*np.sqrt( np.sqrt( Cs*wav*wav*wav) )
    r = np.linspace(0, rmax, nr)
    psf = stemhrCc( r, params )
    # next invert psf to get mtf
    nk = len( k )
    mtf = np.empty( nk, float )
    for ik in range(0, nk, 1 ):
        h = psf * jv(0,2*np.pi*r*k[ik] ) *r
        mtf[ik] = sum(h)

    a = mtf[0]
    mtf = mtf/a  # normalize to mtf(0)=1
    return mtf

#
#-------------- J0() ----------------
#
#  NOTE: this MUST be before it is used in a cfunc !!
#
#  Bessel J0()
#
# real function to return zeroth order Bessel function of the argument
#  using the polynomial expression given on page 369 of
#      Abromowitz and Stegum (good to about 5.0e-8)
#
#  - python.special.jv() does not work inside numba
#  - numba_special has j0() and jv() but is usually not installed
#  by default so use this function for convenience - this has larger
#  error but probably good enough
#
# can be either cfunc or njit 
#@cfunc("float64(float64)")
@njit
def J0( x ):
    p = np.array( [1.0, -2.2499997,  1.2656208, -0.3163866, \
                   0.0444479, -0.0039444, 0.0002100] )
    f = np.array( [0.79788456, -0.00000077, -0.00552740, \
            -0.00009512,  0.00137237, -0.00072805, 0.00014476] )
    y = np.array( [-0.78539816,  -0.04166397, -0.00003954, \
             0.00262573,  -0.00054125, -0.00029333, 0.00013558] )

    xa = np.abs( x )
    if xa < 3.0  :
        x3 = xa/ 3.0
        x3 = x3 * x3
        p0 = p[6]
        for i in range (5,-1,-1):   #( i=5; i>=0; i=i-1)
            p0 = p0 * x3 + p[i]
        return p0
    else:
        x3 = 3.0/xa
        f0 = f[6]
        y0 = y[6]
        for i in range (5,-1,-1):   #(i=5; i>=0; i=i-1) {
            y0 = y0 * x3 + y[i]
            f0 = f0 * x3 + f[i]
        y0 = xa + y0
        return f0*np.cos(y0)/np.sqrt( xa )

#-------- lens(k) ----------------
#
#  dummy function to integrate (used by stempsf)
#  to calculate complex aberr. function
#    input k (in 1/Angs.), wav = electron wavelength
#
#  chi = pi*wav*k^2*[ 0.5*Cs3*wav^2*k^2
#                  + (1/3)*Cs5*wav^4*k^4 - df ]
#  return exp( -i*chi )
#
# args (that used to be globals):
#   w2 = pi*defocus*wav
#   w4 = 0.5*pi*Cs3*wav^3
#   w6 = (1.0/3.0)*pi*Cs5*wav^5
#   intr = 2*pi*r
#
#  started 25-jun-2011 E. Kirkland
#  remove globals 25-dec-2021 ejk
#  convert to cfunc() and J0 for quad() 4-jan-2022 ejk
#
# cfunc and args for integrate.quad
@cfunc("float64(intc, CPointer(float64))")
def lensr( n, a ):    #  real part
    k = a[0]
    w2 = a[1]
    w4 = a[2]
    w6 = a[3]
    intr = a[4]
    k2 = k*k
    w = ( (w6*k2 + w4) *k2 - w2 )*k2
    #return np.cos(w) * jv(0, intr*k )*k # need module numba_special
    return np.cos(w) * J0( intr*k )*k

# cfunc and args for integrate.quad
@cfunc("float64(intc, CPointer(float64))")
def lensi( n, a ):    #  imag part
    k = a[0]
    w2 = a[1]
    w4 = a[2]
    w6 = a[3]
    intr = a[4]
    k2 = k*k
    k2 = k*k
    w = ( (w6*k2 + w4) *k2 - w2 )*k2
    #return -np.sin(w) * jv(0, intr*k )*k # need module numba_special
    return -np.sin(w) * J0( intr*k )*k


