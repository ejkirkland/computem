#  stempsf.py
#
#------------------------------------------------------------------------
#Copyright 2011-2021 Earl J. Kirkland
#
#This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  plot the STEM probe profile
#  this script calls stemhr etc.
#
#  started 25-jun-2011 E. Kirkland
#  small comsmetic changes 30-jun-2014 ejk
#  add probe size 8-jul-2014 ejk
#  add chromatic Cc = ddf integration 9-jul-2014 ejk
#  update to python 3.8 on 23-dec-2021 ejk
#  last modified 23-dec-2021 ejk
#
import numpy as np
import matplotlib.pyplot as plt
from stemh import *
import time

TEST = 0  # 1 for testing , 0 otherwise

print("Plot STEM probe intensity")

cc = 'm'
while( cc in [ 'm', 'M' ]  ) :

    kev  = float( input( 'Type electron energy in keV : '))
    Cs3  = float( input( 'Type spherical aberration Cs3 in mm : '))
    Cs5  = float( input( 'Type spherical aberration Cs5 in mm : '))
    df   = float( input( 'Type defocus df in Angstroms : '))
    amax = float( input( 'Type obj. apert. semiangle in mrad : '))
    ddf  = float( input( 'Type defocus spread FWHM in Angstroms : '))
    p = np.array([kev, Cs3, Cs5, df, amax, ddf ], float)
    #
    wav = wavelen(kev)  # electron wavelength
    Cs = max( 0.1, abs(Cs3) )
    rmax = np.sqrt( np.sqrt( Cs*1.0e7*wav*wav*wav ))
    NPTS = 300   #  number of points in curve
    r = np.linspace( 0, rmax, NPTS)
    if TEST > 0:
        ctime = time.process_time()  #  get start time
    psf = stemhrCc( r, p )
    rfwhm = prbsize( r, psf )
    if TEST > 0:
        ctime = ( time.process_time() - ctime )
        print("CPU time= ",ctime, " sec.")
    print("FWHM-II= ", rfwhm, " Ang.")
    fig, axs = plt.subplots( 1,1, figsize=(8,6), dpi=100)
    axs.plot( r, psf )
    axs.axis([0.0,rmax,0.0,1.0])
    axs.set_xlabel( 'radius in Angstroms')
    axs.set_ylabel( 'PSF' )
    s1 = 'Cs3= %gmm, Cs5= %gmm, ' % (Cs3, Cs5 )
    s2 = 'df= %gA, ' % df
    s3 = 'E= %gkeV, OA= %gmrad, ' % (kev, amax)
    s4 = 'ddf= %gA' % (ddf)
    axs.set_title( s1+s2+s3+s4)
    #savefig( 'stempsf.eps' )  # select file format
    plt.savefig( 'stempsf.pdf' )
    plt.show()
    cc = input('stempsf done, type m to continue : ')
