#
# -------- stemtf.py -------------
#
#------------------------------------------------------------------------
#Copyright 2011-2021 Earl J. Kirkland
#
#This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
#---------------------- NO WARRANTY ------------------
# THIS PROGRAM IS PROVIDED AS-IS WITH ABSOLUTELY NO WARRANTY
# OR GUARANTEE OF ANY KIND, EITHER EXPRESSED OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
# IN NO EVENT SHALL THE AUTHOR BE LIABLE
# FOR DAMAGES RESULTING FROM THE USE OR INABILITY TO USE THIS
# PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA
# BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY YOU OR
# THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH
# ANY OTHER PROGRAM).
#-----------------------------------------------------------------------------
#
#  plot the STEM probe mtf
#  this script calls stemh.py
#
#  started from stemtf.m 1-jul-2011 E. Kirkland
#  small comsmetic changes 30-jun-2014 ejk
#  add chromatic Cc = ddf integration 10-jul-2014 ejk
#  update to python 3.8 on 23-dec-2021 ejk
#  last modified 4-feb-2022 ejk
#
import numpy as np
import matplotlib.pyplot as plt
#from  math import *
from stemh import *
import time

TEST = 0  # 1 for testing , 0 otherwise

print( 'Plot STEM transfer function')

cc = 'm'
while( cc in [ 'm', 'M' ] ) :

    kev  = float( input( 'Type electron energy in keV : '))
    Cs3  = float( input( 'Type spherical aberration Cs3 in mm : '))
    Cs5  = float( input( 'Type spherical aberration Cs5 in mm : '))
    df   = float( input( 'Type defocus df in Angstroms : '))
    amax = float( input( 'Type obj. apert. semiangle in mrad : '))
    ddf  = float( input( 'Type defocus spread FWHM in Angstroms : '))
    p = np.array( [kev, Cs3, Cs5, df, amax, ddf ], float)
    #
    # electron wavelength
    wav = wavelen(kev)  # electron wavelength
    kmax = 2*0.001*amax/wav
    NPTS = 500  # number of points to plot
    k = np.linspace( 0, kmax, NPTS)
    if TEST > 0:
        ctime = time.process_time()  #  get start time
    mtf = stemhk( k, p )
    if TEST > 0:
        ctime = ( time.process_time() - ctime )
        print("CPU time= ",ctime, " sec.")
    fig, axs = plt.subplots( 1,1, figsize=(8,6), dpi=100)
    axs.plot( k, mtf )
    axs.set_xlabel( 'k (inv. Angs.)')
    axs.set_ylabel( 'MTF' )
    axs.axis([0.0,kmax,min(mtf),max(mtf)])
    s1 = 'Cs3= %gmm, Cs5= %gmm, ' % ( Cs3, Cs5 )
    s2 = ' df= %gA, ' %  ( df )
    s3 = 'E= %gkeV, OA= %gmrad, ' % ( kev, amax )
    s4 = 'ddf= %gA' % (ddf)
    axs.set_title( s1 + s2 + s3 + s4 )
    #plt.savefig( 'stemtf.eps' )  # select file format
    plt.savefig( 'stemtf.pdf' )
    plt.show()
    cc = input('stemtf done, type m to continue : ')

